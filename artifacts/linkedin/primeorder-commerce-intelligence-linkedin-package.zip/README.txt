PrimeOrder Commerce Intelligence - LinkedIn package

Recommended normal-post image: assets/linkedin/primeorder-commerce-intelligence-1200x627.png
Carousel alternative: artifacts/linkedin/primeorder-commerce-intelligence-linkedin-carousel.pdf
Use docs/social/LINKEDIN_FIRST_COMMENT.md for the verified public links.
Nothing has been posted to LinkedIn. Review and publish manually.
